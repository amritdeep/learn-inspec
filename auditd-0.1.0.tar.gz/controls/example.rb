describe package('auditd') do
  it { should be_installed }
end
